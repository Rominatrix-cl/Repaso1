from ..models import *
from django import forms

class IngresarProyecto(forms.ModelForm):
    class Meta:
        model = Proyecto
        fields = ['nombre']
        labels = {
            'nombre': 'Nombre del Proyecto'
        }

class IngresarTarea(forms.ModelForm):
    class Meta:
        model = Tarea
        fields =['proyecto', 'titulo', 'descripcion']
        labels= {
            'proyecto': 'Proyecto Asociado',
            'titulo': 'Título',
            'descripcion': 'Descripción'
        }
        