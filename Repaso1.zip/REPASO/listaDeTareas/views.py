from django.shortcuts import render, redirect ,get_object_or_404
from .forms import forms
from .models import *
# Create your views here.

def crearProyecto(request):
    if request.method =='POST':
        formulario_post = forms.IngresarProyecto(request.POST)
        if formulario_post.is_valid():
            formulario_post.save()
        return redirect ('app:verProyectos')
    return render(request, 'crearProyecto.html', {
        'form':forms.IngresarProyecto()
    })

def crearTareas(request):
    if request.method == 'POST':
        formulario_post = forms.IngresarTarea(request.POST)
        if formulario_post.is_valid():
            formulario_post.save()
    return render(request,'crearTareas.html',{
        'form':forms.IngresarTarea()
    })
    
def verProyectos(request):
    proyecto =  Proyecto.objects.all()
    return render(request, 'verProyectos.html',{
        'proyectos':proyecto
    })

def verTareas (request, id):
    proyecto = get_object_or_404(Proyecto,id=id)
    tareas = Tarea.objects.filter(proyecto_id = id)
    return render (request, 'verTareas.html',{
        'proyecto': proyecto,
        'tareas': tareas
    })