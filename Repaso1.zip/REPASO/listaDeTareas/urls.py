from django.urls import path
from .views import *

app_name = 'app'
# http://www.miaplicacion.com/home/
#127.0.0.1:8000/
#localhost:8000/
urlpatterns = [
    path('',crearProyecto, name='crearProyecto'), #'app:crearProyecto'
    path('crearTareas/', crearTareas, name='crearTareas'),
    path('verProyectos/',verProyectos, name='verProyectos'),
    path('verProyectos/verTareas/<int:id>',verTareas, name='verTareas')
    
]
